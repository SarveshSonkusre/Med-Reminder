import "./App.css";
import date18 from "./assets/date18.svg";
const App = () => {
  return (
    <div className="calender">
      <div className="rectangle-20">
        <div className="flex-container">
          <img className="date-18" src={date18} />
          <div className="date-19">
            <button className="rectangle-21">
              <span className="num-19">19</span>
            </button>
          </div>
          <img className="date-20" src={date18} />
        </div>
        <div className="flex-container-1">
          <span>11</span>
          <button className="rectangle-22">12</button>
        </div>
        <div className="flex-container-2">
          <span className="num-21">21</span>
          <div className="rectangle-23">22</div>
          <span>23</span>
        </div>
      </div>
    </div>
  );
};
export default App;
