import "./App.css";
import back from "./assets/back.svg";
import ellipse4 from "./assets/ellipse4.svg";
import group21 from "./assets/group21.svg";
const App = () => {
  return (
    <div className="i-phone-11-pro-x-4">
      <div className="flex-container">
        <img className="back" src={back} />
        <div className="flex-container-1">
          <img className="ellipse-4" src={ellipse4} />
          <img className="group-21" src={group21} />
        </div>
      </div>
      <span className="name">Name</span>
      <button className="rectangle-24">
        <span className="sunita-sharma">Sunita Sharma</span>
      </button>
      <span className="age">Age</span>
      <div className="rectangle-24-1">
        <span className="num-65">65</span>
      </div>
      <span className="disease">Disease</span>
      <div className="rectangle-24-2">
        <span className="high-bp-sugar-astham">High BP, Sugar, Asthama</span>
      </div>
      <span className="last-doctor-visit">Last Doctor Visit</span>
      <div className="rectangle-24-3">
        <span className="num-011022">01&#x2F;10&#x2F;22</span>
      </div>
      <span className="next-doctor-visit">Next Doctor Visit</span>
      <div className="rectangle-24-4">
        <span className="num-050123">05&#x2F;01&#x2F;23</span>
      </div>
      <span className="doctor-name">Doctor Name</span>
    </div>
  );
};
export default App;
