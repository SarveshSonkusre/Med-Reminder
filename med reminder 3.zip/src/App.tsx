import "./App.css";
import group13 from "./assets/group13.svg";
import group14 from "./assets/group14.svg";
import group7 from "./assets/group7.svg";
import group12 from "./assets/group12.svg";
import back from "./assets/back.svg";
const App = () => {
  return (
    <div className="i-phone-11-pro-x-3">
      <img className="back" src={back} />
      <span className="calender">Calender</span>
      <span className="add-date">Add Date</span>
      <select className="rectangle-4">
        <option>DD&#x2F;MM&#x2F;YY</option>
      </select>
      <span className="name-amount">Name &amp; Amount </span>
      <div className="flex-container">
        <div className="rectangle-19">Antinitocin</div>
        <select className="rectangle-7">
          <option className="tuspcidivwiou">1</option>
          <option className="pills">pills</option>
        </select>
      </div>
      <span className="food-pills">Food &amp; Pills</span>
      <div className="flex-container-1">
        <img className="group-14" src={group14} />
        <img className="group-13" src={group13} />
        <img className="group-12" src={group12} />
      </div>
      <span className="notification">Notification</span>
      <div className="flex-container-2">
        <input className="rectangle-8" placeholder="10:00 AM" type="text" />
        <img className="group-7" src={group7} />
      </div>
      <button className="rectangle-3">Done</button>
    </div>
  );
};
export default App;
