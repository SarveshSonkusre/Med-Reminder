import "./App.css";
import addLine22 from "./assets/addLine22.svg";
import group211 from "./assets/group211.svg";
import rectangle2 from "./assets/rectangle2.svg";
import calendarFill1 from "./assets/calendarFill1.svg";
import ellipse4 from "./assets/ellipse4.svg";
import group2 from "./assets/group2.svg";
import dashboardFill1 from "./assets/dashboardFill1.svg";
import message3Fill1 from "./assets/message3Fill1.svg";
import settings from "./assets/settings.svg";
import ellipse3 from "./assets/ellipse3.svg";
import group21 from "./assets/group21.svg";
import arrowRightSLine11 from "./assets/arrowRightSLine11.svg";
import rectangle3 from "./assets/rectangle3.svg";
import arrowRightSLine1 from "./assets/arrowRightSLine1.svg";
const App = () => {
  return (
    <div className="i-phone-11-pro-x-1">
      <input className="rectangle-4" placeholder="Search" type="text" />
      <div className="flex-container">
        <span className="hello-sunita-sharma">Hello, Sunita sharma</span>
        <div className="flex-container-1">
          <img className="ellipse-4" src={ellipse4} />
          <img className="group-21" src={group211} />
        </div>
      </div>
      <div className="rectangle-16">
        <span className="your-plan-for-today">Your plan for today</span>
        <span className="num-1-of-4-completed">1 of 4 completed</span>
        <span className="show-more">Show More</span>
      </div>
      <span className="daily-review">Daily Review</span>
      <div className="rectangle-16-1">
        <img className="group-2" src={group2} />
        <div className="flex-container-2">
          <span>Oxycodone</span>
          <div className="flex-container-3">
            <span className="num-1000-am">10:00 AM</span>
            <img className="ellipse-3" src={ellipse3} />
            <span className="completed">Completed</span>
          </div>
        </div>
        <img className="arrow-right-s-line-1" src={arrowRightSLine1} />
      </div>
      <div className="rectangle-16-2">
        <img className="group-21-1" src={group21} />
        <div className="flex-container-4">
          <span>Naloxone</span>
          <div className="flex-container-5">
            <span>04:00 PM</span>
            <img className="ellipse-31" src={ellipse3} />
          </div>
        </div>
        <span className="skipped">Skipped</span>
        <img className="arrow-right-s-line-11" src={arrowRightSLine11} />
      </div>
      <div className="tab-bar">
        <img className="add-line-22" src={addLine22} />
        <img className="rectangle-3" src={rectangle3} />
        <img className="calendar-fill-1" src={calendarFill1} />
        <img className="dashboard-fill-1" src={dashboardFill1} />
        <img className="settings" src={settings} />
        <img className="message-3-fill-1" src={message3Fill1} />
        <img className="rectangle-2" src={rectangle2} />
        <div className="rectangle-18" />
      </div>
    </div>
  );
};
export default App;
