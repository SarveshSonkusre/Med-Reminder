import "./App.css";
import group21 from "./assets/group21.svg";
import qrScan2Line111 from "./assets/qrScan2Line111.svg";
import group14 from "./assets/group14.svg";
import back from "./assets/back.svg";
import group13 from "./assets/group13.svg";
import group12 from "./assets/group12.svg";
import group7 from "./assets/group7.svg";
const App = () => {
  return (
    <div className="i-phone-11-pro-x-2">
      <img className="back" src={back} />
      <span className="add-plan">Add Plan</span>
      <div className="flex-container">
        <span className="pills-name">Pills name</span>
        <div className="cat-absolute-container">Pills name</div>
      </div>
      <div className="rectangle-4">
        <div className="rectangle-4-1">
          <img className="group-21" src={group21} />
          <span>Paracetamol</span>
          <img className="qr-scan-2-line-111" src={qrScan2Line111} />
        </div>
      </div>
      <span>Amount &amp; How long?</span>
      <div className="flex-container-1">
        <select className="rectangle-7" />
        <select className="rectangle-13">
          <option className="num-30">30</option>
          <option className="days">days</option>
        </select>
      </div>
      <span className="food-pills">Food &amp; Pills</span>
      <div className="flex-container-2">
        <img className="group-14" src={group14} />
        <img className="group-13" src={group13} />
        <img className="group-12" src={group12} />
      </div>
      <span className="notification">Notification</span>
      <div className="flex-container-3">
        <input className="rectangle-8" placeholder="10:00 AM" type="text" />
        <img className="group-7" src={group7} />
      </div>
      <button className="rectangle-3">Done</button>
    </div>
  );
};
export default App;
